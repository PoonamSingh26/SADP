package Lambda_solutions;

import java.util.ArrayList;


public class Test {
	
	public static void main(String[] args) {
		ArrayList<Coordinates> points = new ArrayList<Coordinates>();
		points.add(new Coordinates(0, 0));
		points.add(new Coordinates(-1, 1));
		points.add(new Coordinates(-2, 4));
		points.add(new Coordinates(-2, -3));
		points.add(new Coordinates(-10, 2));
		points.add(new Coordinates(5, -1));
		points.add(new Coordinates(2, 4));
		points.add(new Coordinates(1, 0));
		points.add(new Coordinates(10, 3));
		
		System.out.println("Exercise 1 Solution: \n");
		points.forEach(System.out::println);

}
}
